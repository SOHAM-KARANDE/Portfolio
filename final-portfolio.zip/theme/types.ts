export type ThemeMode = 'light' | 'dark';

export type PaletteColors = {
    [key: string]: string;
};

export interface Palette {
    name: string;
    light: PaletteColors;
    dark: PaletteColors;
}

export type ThemePalettes = {
    [key: string]: Palette;
};
