import { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Chat } from '@google/genai';
import { AI_CONTEXT_DATA } from '../constants';

interface Message {
  role: 'user' | 'model';
  text: string;
}

export const useChat = () => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: 'Hello! I am Soham\'s AI assistant. How can I help you learn more about his work?' }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const chatRef = useRef<Chat | null>(null);

  useEffect(() => {
    const initializeChat = async () => {
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const systemInstruction = `You are a friendly, professional, and helpful AI assistant for a personal portfolio website. 
        Your name is "Spark". You are created by Soham.
        You must answer questions based on the following context about Soham.
        Do not make up information. If the answer is not in the context, say that you don't have that information.
        Keep your answers concise and engaging. You can use markdown for formatting like bolding (**text**).

        Context:
        ${AI_CONTEXT_DATA}
        `;
        
        chatRef.current = ai.chats.create({
            model: 'gemini-2.5-flash',
            config: {
                systemInstruction,
            },
        });
      } catch(e) {
        console.error("Failed to initialize chat:", e);
        setMessages(prev => [...prev, {role: 'model', text: 'Sorry, I am having trouble connecting right now. Please try again later.'}]);
      }
    };
    initializeChat();
  }, []);

  const sendMessage = async (messageText: string) => {
    if (!chatRef.current) {
        setMessages(prev => [...prev, {role: 'model', text: 'The chat is not initialized yet. Please wait a moment.'}]);
        return;
    }

    setIsLoading(true);
    setMessages(prev => [...prev, { role: 'user', text: messageText }]);

    try {
      const response = await chatRef.current.sendMessage({ message: messageText });
      const responseText = response.text;
      
      // A simple markdown to HTML for bolding
      const formattedText = responseText.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

      setMessages(prev => [...prev, { role: 'model', text: formattedText }]);
    } catch (error) {
      console.error('Error sending message:', error);
      setMessages(prev => [...prev, { role: 'model', text: 'Oops, something went wrong. Please try again.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return { messages, sendMessage, isLoading };
};
