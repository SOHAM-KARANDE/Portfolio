import React, { useState } from 'react';
import { SECTIONS, PERSONAL_INFO } from '../constants';
import { LightbulbIcon, MenuIcon } from './icons/Icons';
import ThemePicker from './ThemePicker';
import Button from './Button';
import NavigationDrawer from './NavigationDrawer';
import ChatbotIcon from './ChatbotIcon';

type SectionType = typeof SECTIONS[number];

interface NavbarProps {
  activeSection: SectionType;
  setActiveSection: (section: SectionType) => void;
  onChatClick: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ activeSection, setActiveSection, onChatClick }) => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  return (
    <>
      <header className="sticky top-0 z-30">
        <div className="absolute inset-0 bg-surface-container-low/80 backdrop-blur-md border-b border-outline-variant/50"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            
            <div className="flex items-center space-x-3">
              <ChatbotIcon onClick={onChatClick} />
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 flex items-center justify-center bg-primary-container rounded-full">
                  <LightbulbIcon className="h-5 w-5 text-on-primary-container" />
                </div>
                <span className="font-display text-lg font-bold text-on-surface tracking-tight">{PERSONAL_INFO.name}</span>
              </div>
            </div>

            <div className="flex items-center">
              <nav className="hidden md:flex items-center space-x-1 mr-4">
                {SECTIONS.map(section => (
                    <Button
                        key={section}
                        variant="text"
                        onClick={() => setActiveSection(section as SectionType)}
                        className={`!h-9 !px-4 ${activeSection === section ? 'bg-secondary-container text-on-secondary-container' : 'text-on-surface-variant'}`}
                    >
                        {section}
                    </Button>
                ))}
              </nav>

              <ThemePicker />
              <div className="md:hidden ml-2">
                <Button
                  variant="text"
                  onClick={() => setIsDrawerOpen(true)}
                  className="!w-10 !h-10 !p-0 !rounded-full"
                >
                  <MenuIcon className="w-6 h-6" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </header>
      <NavigationDrawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        activeSection={activeSection}
        setActiveSection={setActiveSection}
      />
    </>
  );
};

export default Navbar;