import React, { useState, useEffect, useRef } from 'react';

interface IntroAnimationProps {
  onAnimationComplete: () => void;
}

const IntroAnimation: React.FC<IntroAnimationProps> = ({ onAnimationComplete }) => {
  const [phase, setPhase] = useState('start'); // 'start', 'tagline', 'boxes', 'fadeout'
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Animate letters in
    const letters = document.querySelectorAll('.letter');
    letters.forEach((letter, index) => {
      setTimeout(() => {
        (letter as HTMLElement).classList.add('visible');
      }, index * 100);
    });

    const nameAnimationTime = letters.length * 100;

    // Sequence to show tagline
    const taglineTimer = setTimeout(() => {
      setPhase('tagline');
    }, nameAnimationTime + 500);

    // Sequence to show boxes
    const boxesTimer = setTimeout(() => {
        setPhase('boxes');
    }, nameAnimationTime + 500 + 500); // 0.5s after tagline starts appearing

    // Sequence to start fade out
    const fadeOutTimer = setTimeout(() => {
      setPhase('fadeout');
    }, nameAnimationTime + 500 + 500 + 2000); // 2s after boxes start appearing

    return () => {
      clearTimeout(taglineTimer);
      clearTimeout(boxesTimer);
      clearTimeout(fadeOutTimer);
    };
  }, []);

  useEffect(() => {
    const node = containerRef.current;
    if (phase === 'fadeout' && node) {
      const handleTransitionEnd = (event: TransitionEvent) => {
        if (event.propertyName === 'opacity') {
          onAnimationComplete();
          node.removeEventListener('transitionend', handleTransitionEnd);
        }
      };
      node.addEventListener('transitionend', handleTransitionEnd);
      return () => {
        if (node) {
          node.removeEventListener('transitionend', handleTransitionEnd);
        }
      };
    }
  }, [phase, onAnimationComplete]);

  const isTaglineVisible = phase === 'tagline' || phase === 'boxes' || phase === 'fadeout';
  const areBoxesVisible = phase === 'boxes' || phase === 'fadeout';

  return (
    <div
      ref={containerRef}
      id="intro-animation-container"
      className={phase === 'fadeout' ? 'fading-out' : ''}
    >
      <div id="soham-name-animation">
        <span className="letter">S</span>
        <span className="letter">O</span>
        <span className="letter">H</span>
        <span className="letter">A</span>
        <span className="letter">M</span>
      </div>
      <div
        id="tagline-soham"
        className={isTaglineVisible ? 'visible' : ''}
      >
        Bringing AI to Life
      </div>
      <div
        id="roles-container"
        className={areBoxesVisible ? 'visible' : ''}
      >
        <div className="role-box">AI & ML Engineer</div>
        <div className="role-box">Freelancer</div>
        <div className="role-box">Gen AI Expert</div>
      </div>
    </div>
  );
};

export default IntroAnimation;
