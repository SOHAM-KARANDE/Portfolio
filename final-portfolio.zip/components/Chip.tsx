import React from 'react';
import { useRipple } from './Ripple';
import { CheckIcon } from './icons/Icons';

interface ChipProps {
  label: string;
  active?: boolean;
  onClick: () => void;
}

const Chip: React.FC<ChipProps> = ({ label, active = false, onClick }) => {
  const { createRipple, RippleElements } = useRipple();

  const baseClasses = 'relative h-8 px-4 flex items-center justify-center rounded-lg border font-medium text-sm overflow-hidden transition-colors duration-200 cursor-pointer';

  const activeClasses = 'bg-secondary-container border-secondary-container text-on-secondary-container';
  const inactiveClasses = 'bg-surface-container border-outline text-on-surface-variant hover:bg-on-surface/10';

  const handleClick = (e: React.MouseEvent<HTMLDivElement>) => {
    createRipple(e);
    onClick();
  };
  
  return (
    <div
      onClick={handleClick}
      className={`${baseClasses} ${active ? activeClasses : inactiveClasses}`}
    >
      {active && <CheckIcon className="w-4 h-4 mr-2" />}
      {label}
      <RippleElements />
    </div>
  );
};

export default Chip;