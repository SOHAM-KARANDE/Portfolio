import React from 'react';

type CardVariant = 'elevated' | 'filled' | 'outlined';

interface CardProps {
  variant?: CardVariant;
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
}

const Card: React.FC<CardProps> = ({ 
  variant = 'elevated', 
  children, 
  className = '', 
  onClick 
}) => {
  const baseClasses = 'relative rounded-xl transition-all duration-300';
  
  const variantClasses = {
    elevated: 'bg-surface-container-low shadow-sm hover:shadow-lg',
    filled: 'bg-surface-container-highest shadow-none hover:shadow-md',
    outlined: 'bg-surface-container border border-outline-variant shadow-none hover:border-outline',
  };

  const stateLayer = 'before:absolute before:inset-0 before:bg-primary before:opacity-0 before:transition-opacity before:duration-200 before:rounded-xl hover:before:opacity-[0.08]';

  return (
    <div
      className={`${baseClasses} ${variantClasses[variant]} ${onClick ? 'cursor-pointer' : ''} ${stateLayer} ${className}`}
      onClick={onClick}
    >
      {children}
    </div>
  );
};

export default Card;