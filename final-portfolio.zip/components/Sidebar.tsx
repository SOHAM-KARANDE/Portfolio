import React from 'react';
import { NAVIGATION_STRUCTURE, PERSONAL_INFO, SECTIONS } from '../constants';
import { LightbulbIcon } from './icons/Icons';

type SectionType = typeof SECTIONS[number];

interface SidebarProps {
  activeSection: SectionType;
  setActiveSection: (section: SectionType) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeSection, setActiveSection }) => {
  return (
    <aside className="fixed top-0 left-0 w-64 h-full bg-surface-container border-r border-outline-variant/30 p-4 overflow-y-auto hidden md:block">
        <div className="flex items-center space-x-2 p-2 mb-4">
            <div className="w-8 h-8 flex items-center justify-center bg-primary-container rounded-full">
            <LightbulbIcon className="h-5 w-5 text-on-primary-container" />
            </div>
            <span className="font-display text-lg font-bold text-on-surface tracking-tight">{PERSONAL_INFO.name}</span>
        </div>
      <nav className="space-y-6">
        {NAVIGATION_STRUCTURE.map(navGroup => (
          <div key={navGroup.group}>
            <h3 className="px-4 mb-2 text-xs font-bold text-on-surface-variant tracking-wider uppercase">{navGroup.group}</h3>
            <ul className="space-y-1">
              {navGroup.items.map(item => (
                <li key={item}>
                  <a
                    href={`#${item.toLowerCase().replace(' ', '-')}`}
                    onClick={(e) => {
                      e.preventDefault();
                      setActiveSection(item as SectionType);
                    }}
                    className={`flex items-center h-10 px-4 mx-2 rounded-full text-sm font-medium transition-colors duration-200 ${
                      activeSection === item
                        ? 'bg-secondary-container text-on-secondary-container'
                        : 'text-on-surface-variant hover:bg-on-surface/10'
                    }`}
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </nav>
    </aside>
  );
};

export default Sidebar;
