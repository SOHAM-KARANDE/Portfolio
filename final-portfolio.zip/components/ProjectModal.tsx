import React, { useState, useEffect } from 'react';
import { Project, Rect } from '../../types';
import { ExternalLinkIcon, GithubIcon, XIcon, ZapIcon } from './icons/Icons';
import Button from './Button';

interface ProjectModalProps {
  project: Project;
  startRect: Rect;
  onClose: () => void;
}

const ProjectModal: React.FC<ProjectModalProps> = ({ project, startRect, onClose }) => {
  const [isAnimatingIn, setIsAnimatingIn] = useState(false);
  const [isClosing, setIsClosing] = useState(false);

  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        handleClose();
      }
    };
    
    // Start animation after a short delay to allow React to render initial state
    const animationTimeout = setTimeout(() => setIsAnimatingIn(true), 10);
    
    window.addEventListener('keydown', handleEsc);
    document.body.style.overflow = 'hidden';

    return () => {
      clearTimeout(animationTimeout);
      window.removeEventListener('keydown', handleEsc);
      document.body.style.overflow = 'auto';
    };
  }, []);

  const handleClose = () => {
    setIsClosing(true);
    // Wait for closing animation to finish before calling parent onClose
    setTimeout(onClose, 300);
  };

  const getModalStyle = () => {
    if (!isAnimatingIn || isClosing) {
      return {
        top: `${startRect.top}px`,
        left: `${startRect.left}px`,
        width: `${startRect.width}px`,
        height: `${startRect.height}px`,
        borderRadius: '12px',
      };
    }
    return {
      top: '0px',
      left: '0px',
      width: '100vw',
      height: '100vh',
      borderRadius: '0px',
    };
  };

  return (
    <div className="fixed inset-0 z-50">
      <div
        className="absolute inset-0 bg-scrim/30 backdrop-blur-sm transition-opacity duration-300"
        style={{ opacity: isAnimatingIn && !isClosing ? 1 : 0 }}
        onClick={handleClose}
      />
      <div
        className="fixed bg-surface-container-low overflow-hidden transition-all duration-400 ease-in-out will-change-transform"
        style={getModalStyle()}
      >
        <div className={`h-full w-full overflow-y-auto transition-opacity duration-200 delay-200 ${isAnimatingIn && !isClosing ? 'opacity-100' : 'opacity-0'}`}>
          <div className="sticky top-0 bg-surface-container-low/80 backdrop-blur-sm z-10 px-6 py-3 flex justify-between items-center border-b border-outline-variant">
            <h2 className="text-2xl font-display font-bold text-on-surface">{project.title}</h2>
            <Button variant="text" onClick={handleClose} className="!w-10 !h-10 !p-0 !rounded-full">
                <XIcon className="w-6 h-6 text-on-surface-variant" />
            </Button>
          </div>

          <div className="p-6 md:p-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="md:col-span-2">
                <img src={project.imageUrl} alt={project.title} className="w-full h-auto object-cover rounded-lg mb-6 shadow-lg" />
                
                <h3 className="text-xl font-display font-semibold mb-2 text-on-surface">The Story</h3>
                <div className="space-y-4 text-on-surface-variant">
                    <p><strong className="text-on-surface">Problem:</strong> {project.problem}</p>
                    <p><strong className="text-on-surface">My Role:</strong> {project.role}</p>
                    <p><strong className="text-on-surface">Solution:</strong> {project.solution}</p>
                </div>

                <h3 className="text-xl font-display font-semibold mt-8 mb-2 text-on-surface">Challenges & Learnings</h3>
                <p className="text-on-surface-variant">{project.challenges}</p>
              </div>

              <div className="md:col-span-1 space-y-6">
                  <div className="space-y-3">
                      {project.liveUrl && (
                          <Button variant="filled" className="w-full" onClick={() => window.open(project.liveUrl)}>
                              Live Demo <ExternalLinkIcon className="w-5 h-5 ml-2" />
                          </Button>
                      )}
                      {project.githubUrl && (
                          <Button variant="outlined" className="w-full" onClick={() => window.open(project.githubUrl)}>
                              View on GitHub <GithubIcon className="w-5 h-5 ml-2" />
                          </Button>
                      )}
                  </div>

                  <div className="bg-surface-container p-4 rounded-xl border border-outline-variant">
                      <h3 className="font-display font-semibold mb-3 text-on-surface-variant">Tech Stack</h3>
                      <div className="flex flex-wrap gap-2">
                          {project.techStack.map(tech => (
                              <span key={tech} className="bg-secondary-container text-on-secondary-container text-sm font-medium px-3 py-1 rounded-full">{tech}</span>
                          ))}
                      </div>
                  </div>

                  <div className="bg-tertiary-container p-4 rounded-xl border border-tertiary-container/80">
                      <div className="flex items-center space-x-3 mb-2">
                          <ZapIcon className="w-6 h-6 text-on-tertiary-container" />
                          <h3 className="font-display font-semibold text-on-tertiary-container">Impact</h3>
                      </div>
                      <p className="text-on-tertiary-container font-medium">{project.impact}</p>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectModal;