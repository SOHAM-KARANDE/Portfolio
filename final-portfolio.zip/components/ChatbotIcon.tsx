import React from 'react';

interface ChatbotIconProps {
  onClick: () => void;
}

const ChatbotIcon: React.FC<ChatbotIconProps> = ({ onClick }) => {
  return (
    <button onClick={onClick} className="chatbot-icon-container" aria-label="Open AI assistant">
      <div className="siri-wave siri-wave-1"></div>
      <div className="siri-wave siri-wave-2"></div>
      <div className="siri-wave siri-wave-3"></div>
      <div className="siri-wave siri-wave-4"></div>
    </button>
  );
};

export default ChatbotIcon;
