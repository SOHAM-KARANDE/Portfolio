import React, { useState, useLayoutEffect } from 'react';

interface RippleItem {
  key: number;
  size: number;
  x: number;
  y: number;
}

export const useRipple = () => {
  const [ripples, setRipples] = useState<RippleItem[]>([]);

  useLayoutEffect(() => {
    if (ripples.length > 0) {
      const timer = setTimeout(() => {
        setRipples(prev => prev.slice(1));
      }, 600);
      return () => clearTimeout(timer);
    }
  }, [ripples]);

  const createRipple = (event: React.MouseEvent<HTMLElement>) => {
    const target = event.currentTarget;
    const rect = target.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height) * 2;
    const x = event.clientX - rect.left - size / 2;
    const y = event.clientY - rect.top - size / 2;
    const newRipple: RippleItem = { key: Date.now(), size, x, y };
    setRipples(prev => [...prev, newRipple]);
  };

  const RippleElements = () => (
    <>
      {ripples.map(ripple => (
        <span
          key={ripple.key}
          className="absolute block bg-on-surface/20 rounded-full animate-ripple-effect pointer-events-none"
          style={{
            left: ripple.x,
            top: ripple.y,
            width: ripple.size,
            height: ripple.size
          }}
        />
      ))}
    </>
  );

  return { createRipple, RippleElements };
};