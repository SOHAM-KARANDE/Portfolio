import React, { useState } from 'react';
import { useTheme } from '../hooks/useTheme';
import { palettes, PaletteName } from '../palettes';
import { PaletteIcon, SunIcon, MoonIcon, CheckIcon } from './icons/Icons';
import Button from './Button';

const ThemePicker: React.FC = () => {
  const { mode, setMode, paletteName, setPaletteName } = useTheme();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="relative">
      <Button
        variant="text"
        onClick={() => setIsOpen(!isOpen)}
        className="!w-10 !h-10 !p-0 !rounded-full"
      >
        <PaletteIcon className="w-6 h-6" />
      </Button>

      {isOpen && (
        <div 
            className="absolute right-0 top-12 w-64 bg-surface-container rounded-2xl shadow-2xl p-4 z-50 animate-fade-in-down"
            onClick={(e) => e.stopPropagation()}
        >
          <div className="text-sm font-medium text-on-surface-variant px-2 pb-2">Theme</div>
          
          <div className="flex items-center justify-between p-2">
            <span className="text-on-surface">Color</span>
            <div className="flex space-x-2">
                {Object.keys(palettes).map((pName) => (
                    <button 
                        key={pName}
                        onClick={() => setPaletteName(pName as PaletteName)}
                        className={`w-6 h-6 rounded-full transition flex items-center justify-center
                            ${paletteName === pName ? 'ring-2 ring-offset-2 ring-offset-surface-container ring-primary' : ''}`}
                        style={{ backgroundColor: `rgb(${palettes[pName as PaletteName].light.primary})`}}
                    >
                      {paletteName === pName && <CheckIcon className="w-4 h-4 text-on-primary" />}
                    </button>
                ))}
            </div>
          </div>

          <div className="flex items-center justify-between p-2 mt-2">
            <span className="text-on-surface">Mode</span>
            <div className="flex items-center bg-surface-container-high rounded-full p-1">
                <button 
                    onClick={() => setMode('light')}
                    className={`p-1.5 rounded-full transition-colors ${mode === 'light' ? 'bg-primary-container text-on-primary-container' : 'text-on-surface-variant'}`}
                >
                    <SunIcon className="w-5 h-5"/>
                </button>
                <button 
                    onClick={() => setMode('dark')}
                    className={`p-1.5 rounded-full transition-colors ${mode === 'dark' ? 'bg-primary-container text-on-primary-container' : 'text-on-surface-variant'}`}
                >
                    <MoonIcon className="w-5 h-5"/>
                </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ThemePicker;