import React, { useEffect } from 'react';
import Card from './Card';
import { XIcon } from './icons/Icons';
import Button from './Button';

interface DialogProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}

const Dialog: React.FC<DialogProps> = ({ isOpen, onClose, title, children }) => {
  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };

    if (isOpen) {
      window.addEventListener('keydown', handleEsc);
      document.body.style.overflow = 'hidden';
    }

    return () => {
      window.removeEventListener('keydown', handleEsc);
      document.body.style.overflow = 'auto';
    };
  }, [isOpen, onClose]);

  if (!isOpen) {
    return null;
  }

  return (
    <div 
        className="fixed inset-0 z-50 flex items-center justify-center p-4"
        aria-labelledby="dialog-title"
        role="dialog"
        aria-modal="true"
    >
      <div 
        className="absolute inset-0 bg-scrim/30 backdrop-blur-sm animate-fade-in"
        onClick={onClose}
      />
      <div className="relative animate-fade-in-down w-full max-w-lg">
        <Card variant="elevated">
            <div className="flex justify-between items-center p-4 border-b border-outline-variant">
              <h2 id="dialog-title" className="text-xl font-display text-on-surface">{title}</h2>
              <Button variant="text" onClick={onClose} className="!w-10 !h-10 !p-0 !rounded-full">
                <XIcon className="w-6 h-6" />
              </Button>
            </div>
            {children}
        </Card>
      </div>
    </div>
  );
};

export default Dialog;
