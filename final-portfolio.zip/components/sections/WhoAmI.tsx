import React from 'react';
import { HOBBIES_DATA, ASPIRATIONS_DATA } from '../../constants';
import { SparklesIcon } from '../icons/Icons';
import Card from '../Card';

const WhoAmI: React.FC = () => {
  return (
    <section id="who-am-i" className="py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-display font-bold text-on-surface">The Person Behind the Code</h2>
          <p className="mt-4 text-lg text-on-surface-variant max-w-2xl mx-auto">
            A glimpse into my world beyond the terminal.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          
          <div className="lg:col-span-2 md:col-span-1">
            <Card variant="filled" className="h-full">
              <div className="p-6">
                <h3 className="text-2xl font-bold mb-6 text-tertiary">Aspirations</h3>
                <div className="space-y-4">
                  {ASPIRATIONS_DATA.map((aspiration, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <SparklesIcon className="w-5 h-5 text-tertiary flex-shrink-0 mt-1" />
                      <p className="text-on-surface-variant">{aspiration}</p>
                    </div>
                  ))}
                </div>
              </div>
            </Card>
          </div>

          <div className="lg:col-span-2 md:col-span-1">
             <div className="group relative rounded-xl overflow-hidden shadow-lg h-full transform transition-transform duration-300 hover:-translate-y-1 hover:shadow-tertiary/20">
              <img src={HOBBIES_DATA[0].imageUrl} alt={HOBBIES_DATA[0].name} className="h-full w-full object-cover min-h-[300px]" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
              <div className="absolute bottom-0 left-0 p-4">
                <h4 className="font-bold text-white text-lg">{HOBBIES_DATA[0].name}</h4>
                <p className="text-sm text-gray-300 opacity-0 group-hover:opacity-100 transition-opacity duration-300">{HOBBIES_DATA[0].description}</p>
              </div>
            </div>
          </div>
          
          {HOBBIES_DATA.slice(1).map((hobby, index) => (
            <div key={index} className="lg:col-span-1 md:col-span-1">
               <div className="group relative rounded-xl overflow-hidden shadow-lg h-full transform transition-transform duration-300 hover:-translate-y-1 hover:shadow-tertiary/20">
                <img src={hobby.imageUrl} alt={hobby.name} className="h-full w-full object-cover min-h-[300px]" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
                <div className="absolute bottom-0 left-0 p-4">
                  <h4 className="font-bold text-white text-lg">{hobby.name}</h4>
                  <p className="text-sm text-gray-300 opacity-0 group-hover:opacity-100 transition-opacity duration-300">{hobby.description}</p>
                </div>
              </div>
            </div>
          ))}

          <div className="lg:col-span-1 md:col-span-2">
            <Card variant="outlined" className="h-full">
                <div className="p-6">
                    <h3 className="text-xl font-bold mb-4 text-tertiary">My Digital Library</h3>
                    <p className="text-on-surface-variant text-sm">Links to my favorite internet archives, YouTube playlists, and recommended software coming soon. A curated collection of what fuels my creativity and learning.</p>
                </div>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhoAmI;