import React, { useState } from 'react';
import { AI_SERVICES_DATA, AI_TOOLS_DATA, AI_RESOURCES_DATA } from '../../constants';
import { ExternalLinkIcon, GithubIcon } from '../icons/Icons';
import Card from '../Card';
import Button from '../Button';
import Spline3D from '../Spline3D';

type ResourceCategory = 'Courses' | 'Datasets' | 'Libraries' | 'Papers';

const AIZone: React.FC = () => {
  const [activeResourceTab, setActiveResourceTab] = useState<ResourceCategory>('Courses');
  
  return (
    <section id="ai-zone" className="py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-display font-bold text-on-surface">The AI Knowledge Hub</h2>
          <p className="mt-4 text-lg text-on-surface-variant max-w-2xl mx-auto">
            A curated space for services, tools, and resources to navigate the world of AI.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          <div className="lg:col-span-2">
             <Card variant="elevated" className="h-full flex flex-col">
                <div className="p-6">
                  <h3 className="text-2xl font-display font-bold text-on-surface">AI: A Visual Exploration</h3>
                  <p className="text-on-surface-variant mb-4">An interactive, theme-aware representation of a neural network.</p>
                </div>
                <div className="flex-grow w-full h-full p-4 bg-surface-container-lowest rounded-b-xl overflow-hidden">
                    <Spline3D />
                </div>
             </Card>
          </div>

          <div className="lg:col-span-1 space-y-8">
            <Card variant="filled" className="p-6">
              <h3 className="text-2xl font-display font-bold mb-4 text-on-surface-variant">My AI Services</h3>
              <ul className="space-y-4">
                {AI_SERVICES_DATA.map((service, i) => (
                  <li key={i} className="flex items-start space-x-4">
                    <div className="flex-shrink-0 bg-primary-container text-on-primary-container p-2 rounded-full mt-1">
                        <service.Icon className="h-5 w-5" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-on-surface-variant">{service.title}</h4>
                      <p className="text-sm text-on-surface-variant/80">{service.description}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </Card>
            
            <Card variant="filled" className="p-6">
              <h3 className="text-2xl font-display font-bold mb-4 text-on-surface-variant">Free AI Tools</h3>
              <div className="space-y-4">
                {AI_TOOLS_DATA.map((tool, i) => (
                  <div key={i} className="border-t border-outline-variant pt-4 first:border-t-0">
                    <h4 className="font-semibold text-on-surface-variant">{tool.name}</h4>
                    <p className="text-sm text-on-surface-variant/80 mb-3">{tool.description}</p>
                    <div className="flex space-x-2">
                      <Button variant='text' className="!h-8 !px-3" onClick={() => window.open(tool.toolUrl)}>Use Tool <ExternalLinkIcon className="w-4 h-4 ml-2" /></Button>
                      <Button variant='text' className="!h-8 !px-3 !text-on-surface-variant" onClick={() => window.open(tool.sourceUrl)}>Source <GithubIcon className="w-4 h-4 ml-2" /></Button>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
          
          <div className="lg:col-span-3">
             <Card variant="elevated" className="p-6">
              <h3 className="text-2xl font-display font-bold mb-4 text-on-surface">Curated AI Resources</h3>
              <div className="border-b border-outline-variant">
                <nav className="-mb-px flex space-x-4" aria-label="Tabs">
                  {(Object.keys(AI_RESOURCES_DATA) as ResourceCategory[]).map(tab => (
                     <button
                        key={tab}
                        onClick={() => setActiveResourceTab(tab)}
                        className={`whitespace-nowrap pb-3 px-1 border-b-2 font-medium text-base transition-colors ${
                            activeResourceTab === tab ? 'border-primary text-primary' : 'border-transparent text-on-surface-variant hover:border-on-surface-variant/50'
                        }`}
                        >
                        {tab}
                    </button>
                  ))}
                </nav>
              </div>
              <ul className="mt-6 space-y-2">
                {AI_RESOURCES_DATA[activeResourceTab].map((res, i) => (
                    <li key={i}>
                        <a href={res.url} target="_blank" rel="noopener noreferrer" className="group flex items-center justify-between p-3 rounded-lg hover:bg-on-surface/5 transition-colors">
                            <div>
                                <h4 className="font-semibold text-on-surface">{res.title}</h4>
                                <p className="text-sm text-on-surface-variant">{res.description}</p>
                            </div>
                            <ExternalLinkIcon className="h-5 w-5 text-on-surface-variant/50 group-hover:text-primary transition-colors" />
                        </a>
                    </li>
                ))}
              </ul>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AIZone;