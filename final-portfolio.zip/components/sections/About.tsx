import React, { useState, useMemo } from 'react';
import { PERSONAL_INFO, IMPACT_STATS_DATA, SKILLS_DATA, EDUCATION_DATA, PROJECTS_DATA, MAP_HOTSPOTS_DATA, PRINCIPLES_DATA } from '../../constants';
import { LinkIcon, BriefcaseIcon, GraduationCapIcon } from '../icons/Icons';
import Card from '../Card';
import Chip from '../Chip';
import Dialog from '../Dialog';
import Button from '../Button';
import StatCounter from '../StatCounter';
import { MapHotspot } from '../../types';

const About: React.FC = () => {
  const [selectedSkill, setSelectedSkill] = useState<string | null>(null);
  const [activeHotspot, setActiveHotspot] = useState<MapHotspot | null>(null);

  const evidenceTimeline = useMemo(() => {
    const education = EDUCATION_DATA.map(e => ({ ...e, type: 'Education' as const, year: parseInt(e.dates.split(' - ')[1] || e.dates, 10) }));
    const projects = PROJECTS_DATA.map(p => ({ ...p, type: 'Project' as const }));
    return [...education, ...projects].sort((a, b) => b.year - a.year);
  }, []);

  const handleSkillClick = (skill: string) => {
    setSelectedSkill(prev => (prev === skill ? null : skill));
  };
  
  const isSkillInItem = (item: (typeof evidenceTimeline)[0], skill: string | null): boolean => {
    if (!skill) return false;
    return item.skills.includes(skill);
  };

  return (
    <section id="about" className="py-16 overflow-x-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Headline */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-6xl font-display font-bold text-on-surface tracking-tighter leading-tight">
            I BUILD INTELLIGENT SYSTEMS<br />FROM THE <span className="text-primary">GROUND UP</span>.
          </h1>
        </div>

        {/* Asymmetrical Bio + Impact Bar */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8 md:gap-12 items-center mb-24">
          <div className="md:col-span-2 flex justify-center">
            <div className="relative">
              <div className="absolute -inset-1.5 bg-gradient-to-br from-primary to-tertiary rounded-full blur-xl opacity-60 animate-pulse-slow"></div>
              <img src={PERSONAL_INFO.photoUrl} alt="Portrait" className="relative rounded-full h-52 w-52 md:h-64 md:w-64 object-cover ring-4 ring-surface-container-low p-1" />
            </div>
          </div>
          <div className="md:col-span-3 text-center md:text-left">
            <p className="text-xl text-on-surface-variant mb-8">{PERSONAL_INFO.synopsis}</p>
            <div className="grid grid-cols-3 gap-4">
              {IMPACT_STATS_DATA.map(stat => (
                <div key={stat.label} className="bg-surface-container text-center p-4 rounded-xl">
                  <span className="text-4xl font-display font-bold text-primary">
                    <StatCounter endValue={stat.value} />
                    {stat.suffix}
                  </span>
                  <p className="text-xs text-on-surface-variant mt-1">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Skill-to-Proof Weaver */}
        <div className="mb-24">
          <h2 className="text-3xl font-display font-bold text-center mb-4 text-on-surface">Skill-to-Proof Weaver</h2>
          <p className="text-lg text-on-surface-variant text-center max-w-3xl mx-auto mb-10">Connect the dots. Click a skill to see where I've learned and applied it.</p>
          <Card variant="filled" className="p-6 md:p-8">
            <div className="text-center mb-8">
              <div className="flex flex-wrap justify-center gap-3">
                {SKILLS_DATA.map(skill => (
                  <Chip
                    key={skill.name}
                    label={skill.name}
                    active={selectedSkill === skill.name}
                    onClick={() => handleSkillClick(skill.name)}
                  />
                ))}
              </div>
            </div>

            <div className="max-w-3xl mx-auto space-y-8">
              {evidenceTimeline.map((item, index) => (
                <div key={index} className={`transition-opacity duration-300 ${selectedSkill && !isSkillInItem(item, selectedSkill) ? 'opacity-30' : 'opacity-100'}`}>
                  <Card variant="outlined" className={`p-6 transition-all duration-300 ${isSkillInItem(item, selectedSkill) ? 'border-primary ring-2 ring-primary' : ''}`}>
                    <div className="flex items-start space-x-4">
                      <div className="flex-shrink-0 mt-1 h-10 w-10 rounded-full bg-secondary-container flex items-center justify-center ring-4 ring-surface-container">
                        {item.type === 'Project' ? <BriefcaseIcon className="h-5 w-5 text-on-secondary-container" /> : <GraduationCapIcon className="h-6 w-6 text-on-secondary-container" />}
                      </div>
                      <div>
                        <h4 className="text-lg font-display font-semibold text-on-surface">{'degree' in item ? item.degree : item.title}</h4>
                        <p className="text-primary font-medium">{'institution' in item ? item.institution : `Project (${item.year})`}</p>
                        {'dates' in item && <p className="text-sm text-on-surface-variant mb-3">{item.dates}</p>}
                        <div className="flex flex-wrap gap-2 mb-3">
                          {item.skills.map(skill => (
                            <span key={skill} className={`text-xs font-medium px-2 py-1 rounded-full transition-colors ${selectedSkill === skill ? 'bg-primary-container text-on-primary-container' : 'bg-secondary-container text-on-secondary-container'}`}>{skill}</span>
                          ))}
                        </div>
                        {'credentialUrl' in item && (
                           <a href={item.credentialUrl} className="inline-flex items-center text-sm font-medium text-primary hover:underline">
                             View Credential <LinkIcon className="w-4 h-4 ml-1" />
                           </a>
                        )}
                      </div>
                    </div>
                  </Card>
                </div>
              ))}
            </div>
          </Card>
        </div>
        
        {/* Interactive Origin Map */}
        <div className="mb-24">
            <h2 className="text-3xl font-display font-bold text-center mb-4 text-on-surface">My Origin Story</h2>
            <p className="text-lg text-on-surface-variant text-center max-w-3xl mx-auto mb-10">Explore the places that shaped my journey.</p>
            <Card variant="filled" className="p-4 h-96 md:h-[30rem] relative overflow-hidden">
                <div className="absolute inset-0 bg-surface-container-lowest">
                    {/* Simplified map-like background */}
                    <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" className="absolute inset-0">
                        <defs>
                            <pattern id="grid" width="80" height="80" patternUnits="userSpaceOnUse">
                                <path d="M 80 0 L 0 0 0 80" fill="none" stroke="rgb(var(--color-surface-container-high))" strokeWidth="1"/>
                            </pattern>
                        </defs>
                        <rect width="100%" height="100%" fill="url(#grid)" />
                    </svg>
                </div>
                {MAP_HOTSPOTS_DATA.map(hotspot => (
                    <div key={hotspot.id} className="absolute" style={{ top: hotspot.position.top, left: hotspot.position.left }}>
                        <Button variant="extended-fab" onClick={() => setActiveHotspot(hotspot)} className="!h-12 !w-12 !p-0 !rounded-full">
                            <hotspot.Icon className="w-6 h-6" />
                        </Button>
                    </div>
                ))}
            </Card>
        </div>

        {/* Guiding Principles */}
        <div>
            <h2 className="text-3xl font-display font-bold text-center mb-4 text-on-surface">My Guiding Principles</h2>
            <p className="text-lg text-on-surface-variant text-center max-w-3xl mx-auto mb-10">The philosophies that drive my work.</p>
            <div className="flex gap-8 pb-4 -mx-4 px-4 overflow-x-auto snap-x snap-mandatory">
                {PRINCIPLES_DATA.map((principle, index) => (
                    <div key={index} className="snap-center flex-shrink-0 w-full md:w-1/3">
                        <Card variant="elevated" className="p-8 h-full">
                            <h4 className="text-2xl font-display font-bold text-tertiary mb-4">{principle.title}</h4>
                            <p className="text-on-surface-variant">{principle.description}</p>
                        </Card>
                    </div>
                ))}
            </div>
        </div>

      </div>

      {activeHotspot && (
        <Dialog
          isOpen={!!activeHotspot}
          onClose={() => setActiveHotspot(null)}
          title={activeHotspot.title}
        >
            <div className="p-6">
                <p className="text-on-surface-variant">{activeHotspot.content}</p>
                 <div className="mt-6 text-right">
                    <Button onClick={() => setActiveHotspot(null)}>Close</Button>
                </div>
            </div>
        </Dialog>
      )}
    </section>
  );
};

export default About;