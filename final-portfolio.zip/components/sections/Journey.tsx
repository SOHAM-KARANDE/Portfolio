import React, { useState, useMemo } from 'react';
import { JOURNEY_DATA, TESTIMONIALS_DATA } from '../../constants';
import { JobType } from '../../types';
import { BriefcaseIcon, CertificateIcon, UsersIcon, LinkIcon } from '../icons/Icons';
import Chip from '../Chip';
import Card from '../Card';

const getIconForType = (type: JobType) => {
  const props = { className: "h-6 w-6 text-on-secondary-container" };
  switch (type) {
    case JobType.EMPLOYMENT: return <BriefcaseIcon {...props} />;
    case JobType.FREELANCE: return <UsersIcon {...props} />;
    case JobType.CERTIFICATION: return <CertificateIcon {...props} />;
    default: return null;
  }
};

const Journey: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState<JobType | 'All'>('All');

  const filteredJourney = useMemo(() => {
    if (activeFilter === 'All') return JOURNEY_DATA;
    return JOURNEY_DATA.filter(item => item.type === activeFilter);
  }, [activeFilter]);

  const filters: (JobType | 'All')[] = ['All', JobType.EMPLOYMENT, JobType.FREELANCE, JobType.CERTIFICATION];

  return (
    <section id="journey" className="py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-display font-bold text-on-surface">Building Trust Through Experience</h2>
          <p className="mt-4 text-lg text-on-surface-variant max-w-2xl mx-auto">My professional history is a testament to my dedication and growth.</p>
        </div>

        <div className="flex justify-center gap-3 mb-12 flex-wrap">
          {filters.map(filter => (
            <Chip
              key={filter}
              label={filter}
              active={activeFilter === filter}
              onClick={() => setActiveFilter(filter)}
            />
          ))}
        </div>

        <div className="max-w-3xl mx-auto">
          <div className="relative space-y-12">
            <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-outline-variant" aria-hidden="true"></div>
            {filteredJourney.map((item, index) => (
              <div key={index} className="relative pl-16">
                <div className="absolute top-0 left-0 h-12 w-12 rounded-full bg-secondary-container flex items-center justify-center ring-8 ring-surface-container-low">
                  {getIconForType(item.type)}
                </div>
                <Card variant="outlined" className="p-6">
                    <div className="flex justify-between items-start mb-1">
                        <h3 className="text-lg font-display font-semibold text-on-surface">{item.role}</h3>
                        <span className="text-xs font-bold text-on-surface-variant uppercase tracking-wider">{item.type}</span>
                    </div>
                    <p className="text-primary font-medium mb-1">{item.company}</p>
                    <p className="text-sm text-on-surface-variant mb-4">{item.dates}</p>
                    <ul className="space-y-2 list-disc list-inside text-on-surface-variant/80">
                        {item.achievements.map((ach, i) => <li key={i}>{ach}</li>)}
                    </ul>
                    {item.credentialUrl && (
                        <a href={item.credentialUrl} className="inline-flex items-center text-sm font-medium text-primary hover:underline transition-colors mt-4">
                            View Credential <LinkIcon className="w-4 h-4 ml-1" />
                        </a>
                    )}
                </Card>
              </div>
            ))}
          </div>
        </div>

        <div className="max-w-4xl mx-auto mt-24">
            <h3 className="text-3xl font-display font-bold text-center mb-12 text-on-surface">Client Feedback</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {TESTIMONIALS_DATA.map((t, i) => (
                    <Card key={i} variant="filled" className="p-6">
                        <blockquote className="h-full flex flex-col">
                            <p className="text-on-surface-variant italic flex-grow">"{t.quote}"</p>
                            <footer className="mt-4 text-right font-semibold text-on-surface">- {t.author}</footer>
                        </blockquote>
                    </Card>
                ))}
            </div>
        </div>
      </div>
    </section>
  );
};

export default Journey;