import React, { useState } from 'react';
import { PROJECTS_DATA } from '../../constants';
import { Project, Rect } from '../../types';
import ProjectCard from '../ProjectCard';
import ProjectModal from '../ProjectModal';

const Projects: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [clickedCardRect, setClickedCardRect] = useState<Rect | null>(null);

  const handleSelectProject = (project: Project, cardElement: HTMLElement) => {
    setClickedCardRect(cardElement.getBoundingClientRect());
    setSelectedProject(project);
  };

  const handleCloseModal = () => {
    setSelectedProject(null);
  };

  return (
    <section id="projects" className="py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-display font-bold text-on-surface">Proof of Intelligence</h2>
          <p className="mt-4 text-lg text-on-surface-variant max-w-2xl mx-auto">
            It's not just about what I can do, but what I have done. Here are some of my creations.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {PROJECTS_DATA.map((project) => (
            <ProjectCard 
              key={project.id} 
              project={project} 
              onSelect={handleSelectProject}
              isSelected={selectedProject?.id === project.id}
            />
          ))}
        </div>
      </div>

      {selectedProject && clickedCardRect && (
        <ProjectModal 
            project={selectedProject} 
            startRect={clickedCardRect}
            onClose={handleCloseModal} 
        />
      )}
    </section>
  );
};

export default Projects;