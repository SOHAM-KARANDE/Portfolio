import React, { useState } from 'react';
import Button from './Button';

interface SegmentedButtonProps {
  segments: string[];
  onSelect: (segment: string) => void;
  initialSegment?: string;
}

const SegmentedButton: React.FC<SegmentedButtonProps> = ({ segments, onSelect, initialSegment }) => {
  const [activeSegment, setActiveSegment] = useState(initialSegment || segments[0]);

  const handleSelect = (segment: string) => {
    setActiveSegment(segment);
    onSelect(segment);
  };

  return (
    <div className="flex w-full rounded-full border border-outline bg-surface-container p-1" role="group">
      {segments.map((segment) => (
        <Button
          key={segment}
          onClick={() => handleSelect(segment)}
          variant="text"
          aria-pressed={activeSegment === segment}
          className={`flex-1 !h-9 !rounded-full !border-none !transition-all !duration-300
            ${activeSegment === segment
              ? 'bg-secondary-container text-on-secondary-container shadow-sm'
              : 'text-on-surface-variant hover:!bg-on-surface/5'
            }`}
        >
          {segment}
        </Button>
      ))}
    </div>
  );
};

export default SegmentedButton;