import React, { useRef } from 'react';
import { Project } from '../../types';
import { ArrowRightIcon } from './icons/Icons';
import Card from './Card';

interface ProjectCardProps {
  project: Project;
  onSelect: (project: Project, element: HTMLElement) => void;
  isSelected: boolean;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ project, onSelect, isSelected }) => {
  const cardRef = useRef<HTMLDivElement>(null);

  const handleClick = () => {
    if (cardRef.current) {
      onSelect(project, cardRef.current);
    }
  };

  return (
    <div ref={cardRef} style={{ opacity: isSelected ? 0 : 1 }} className="group will-change-transform">
      <Card
        variant="filled"
        onClick={handleClick}
        className="!p-0 !overflow-hidden h-full flex flex-col cursor-pointer"
      >
        <div className="relative">
          <img src={project.imageUrl} alt={project.title} className="w-full h-56 object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent"></div>
          <div className="absolute bottom-0 left-0 p-4">
            <h3 className="text-xl font-display font-bold text-white">{project.title}</h3>
            <p className="text-sm text-gray-200">{project.tagline}</p>
          </div>
        </div>
        <div className="p-5 bg-surface-container-highest flex-grow flex flex-col justify-between">
          <div className="flex flex-wrap gap-2 mb-4">
              {project.techStack.slice(0, 3).map(tech => (
                  <span key={tech} className="text-xs font-medium bg-secondary-container text-on-secondary-container px-2 py-1 rounded-full">{tech}</span>
              ))}
              {project.techStack.length > 3 && (
                  <span className="text-xs font-medium bg-secondary-container text-on-secondary-container px-2 py-1 rounded-full">+{project.techStack.length - 3} more</span>
              )}
          </div>
          <div className="flex justify-end">
              <span className="flex items-center text-sm font-semibold text-primary">
                View Case Study
                <ArrowRightIcon className="w-4 h-4 ml-2 transform transition-transform duration-300 group-hover:translate-x-1" />
              </span>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default ProjectCard;