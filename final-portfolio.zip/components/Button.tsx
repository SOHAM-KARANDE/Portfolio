import React, { forwardRef } from 'react';
import { useRipple } from './Ripple';

type ButtonVariant = 'filled' | 'outlined' | 'text' | 'extended-fab';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  children: React.ReactNode;
  leftIcon?: React.ReactNode;
}

const Button = forwardRef<HTMLButtonElement, ButtonProps>(({ 
  variant = 'filled', 
  children, 
  leftIcon,
  className, 
  ...props 
}, ref) => {
  const { createRipple, RippleElements } = useRipple();

  const baseClasses = 'relative group overflow-hidden transition-all duration-300 ease-in-out flex items-center justify-center h-10 px-6 font-display font-medium text-sm rounded-full focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-primary';

  const variantClasses = {
    filled: 'bg-primary text-on-primary shadow-sm hover:shadow-md',
    outlined: 'border border-outline text-primary hover:bg-primary/10',
    text: 'text-primary hover:bg-primary/10',
    'extended-fab': 'h-14 px-5 bg-primary-container text-on-primary-container shadow-lg hover:shadow-xl'
  };

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    createRipple(e);
    if (props.onClick) {
      props.onClick(e);
    }
  };

  return (
    <button
      ref={ref}
      className={`${baseClasses} ${variantClasses[variant]} ${className}`}
      {...props}
      onClick={handleClick}
    >
      {leftIcon && <span className="mr-2 -ml-1">{leftIcon}</span>}
      <span className="z-10">{children}</span>
      <RippleElements />
    </button>
  );
});

Button.displayName = 'Button';

export default Button;