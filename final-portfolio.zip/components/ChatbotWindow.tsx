import React, { useState, useRef, useEffect } from 'react';
import Card from './Card';
import Button from './Button';
import { XIcon, SendIcon } from './icons/Icons';
import { useChat } from '../hooks/useChat';

interface ChatbotWindowProps {
  isOpen: boolean;
  onClose: () => void;
}

const ChatbotWindow: React.FC<ChatbotWindowProps> = ({ isOpen, onClose }) => {
  const { messages, sendMessage, isLoading } = useChat();
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages, isLoading]);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isOpen]);

  const handleSend = () => {
    if (input.trim()) {
      sendMessage(input.trim());
      setInput('');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-end p-4 chatbot-window-container">
      <div className="absolute inset-0 bg-scrim/30 backdrop-blur-sm" onClick={onClose}></div>
      <div className="relative w-full max-w-md h-[70vh] max-h-[600px] flex flex-col">
        <Card variant="elevated" className="h-full w-full flex flex-col !rounded-2xl">
          {/* Header */}
          <div className="flex justify-between items-center p-4 border-b border-outline-variant flex-shrink-0">
            <h2 className="text-xl font-display text-on-surface">AI Assistant</h2>
            <Button variant="text" onClick={onClose} className="!w-10 !h-10 !p-0 !rounded-full">
              <XIcon className="w-6 h-6" />
            </Button>
          </div>

          {/* Messages */}
          <div className="flex-grow p-4 overflow-y-auto space-y-4">
            {messages.map((msg, index) => (
              <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div
                  className={`max-w-[80%] px-4 py-2 rounded-2xl ${
                    msg.role === 'user'
                      ? 'bg-primary-container text-on-primary-container rounded-br-lg'
                      : 'bg-surface-container-high text-on-surface-variant rounded-bl-lg'
                  }`}
                >
                  <p className="text-sm" dangerouslySetInnerHTML={{ __html: msg.text.replace(/\n/g, '<br />') }}></p>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="max-w-[80%] px-4 py-2 rounded-2xl bg-surface-container-high text-on-surface-variant rounded-bl-lg">
                  <div className="typing-indicator">
                    <span></span><span></span><span></span>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-outline-variant flex-shrink-0">
            <div className="flex items-center space-x-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask me anything..."
                className="w-full h-12 px-4 bg-surface-container-highest rounded-full border border-outline focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <Button onClick={handleSend} disabled={isLoading || !input.trim()} className="!w-12 !h-12 !p-0 !rounded-full">
                <SendIcon className="w-6 h-6" />
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default ChatbotWindow;
