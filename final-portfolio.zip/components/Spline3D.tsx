import React from 'react';

const Spline3D: React.FC = () => {
    return (
      <div className="relative w-full h-full min-h-[300px] flex items-center justify-center">
        <svg viewBox="0 0 400 400" className="w-full h-full absolute animate-pulse-slow">
            <defs>
                <filter id="glow">
                    <feGaussianBlur stdDeviation="3.5" result="coloredBlur" />
                    <feMerge>
                        <feMergeNode in="coloredBlur" />
                        <feMergeNode in="SourceGraphic" />
                    </feMerge>
                </filter>
            </defs>
            {/* Connections */}
            <line x1="120" y1="120" x2="200" y2="200" stroke="rgb(var(--color-outline))" strokeWidth="1" />
            <line x1="120" y1="120" x2="280" y2="120" stroke="rgb(var(--color-outline))" strokeWidth="1" />
            <line x1="120" y1="280" x2="200" y2="200" stroke="rgb(var(--color-outline))" strokeWidth="1" />
            <line x1="120" y1="280" x2="280" y2="280" stroke="rgb(var(--color-outline))" strokeWidth="1" />
            <line x1="280" y1="120" x2="200" y2="200" stroke="rgb(var(--color-outline))" strokeWidth="1" />
            <line x1="280" y1="280" x2="200" y2="200" stroke="rgb(var(--color-outline))" strokeWidth="1" />
            <line x1="120" y1="120" x2="200" y2="50" stroke="rgb(var(--color-outline))" strokeWidth="1" />
            <line x1="280" y1="120" x2="200" y2="50" stroke="rgb(var(--color-outline))" strokeWidth="1" />
             <line x1="200" y1="350" x2="120" y2="280" stroke="rgb(var(--color-outline))" strokeWidth="1" />
            <line x1="200" y1="350" x2="280" y2="280" stroke="rgb(var(--color-outline))" strokeWidth="1" />

            {/* Nodes */}
            <circle cx="200" cy="200" r="25" fill="rgb(var(--color-primary-container))" stroke="rgb(var(--color-primary))" strokeWidth="2" filter="url(#glow)" />
            <circle cx="120" cy="120" r="15" fill="rgb(var(--color-secondary-container))" stroke="rgb(var(--color-secondary))" strokeWidth="2" />
            <circle cx="280" cy="120" r="15" fill="rgb(var(--color-secondary-container))" stroke="rgb(var(--color-secondary))" strokeWidth="2" />
            <circle cx="120" cy="280" r="15" fill="rgb(var(--color-secondary-container))" stroke="rgb(var(--color-secondary))" strokeWidth="2" />
            <circle cx="280" cy="280" r="15" fill="rgb(var(--color-secondary-container))" stroke="rgb(var(--color-secondary))" strokeWidth="2" />
            <circle cx="200" cy="50" r="12" fill="rgb(var(--color-tertiary-container))" stroke="rgb(var(--color-tertiary))" strokeWidth="2" />
            <circle cx="200" cy="350" r="12" fill="rgb(var(--color-tertiary-container))" stroke="rgb(var(--color-tertiary))" strokeWidth="2" />
        </svg>
      </div>
    );
};

export default Spline3D;