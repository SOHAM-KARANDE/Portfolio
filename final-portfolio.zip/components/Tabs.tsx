import React, { useState, useRef, useEffect } from 'react';
import Button from './Button';

interface TabsProps {
  tabs: string[];
  onTabChange: (tab: string) => void;
}

const Tabs: React.FC<TabsProps> = ({ tabs, onTabChange }) => {
  const [activeTab, setActiveTab] = useState(0);
  const [indicatorStyle, setIndicatorStyle] = useState({});
  const tabsRef = useRef<(HTMLButtonElement | null)[]>([]);

  useEffect(() => {
    const activeTabNode = tabsRef.current[activeTab];
    if (activeTabNode) {
      setIndicatorStyle({
        left: activeTabNode.offsetLeft,
        width: activeTabNode.offsetWidth,
      });
      onTabChange(tabs[activeTab]);
    }
  }, [activeTab, tabs, onTabChange]);

  return (
    <div className="relative border-b border-outline-variant">
      <div className="flex">
        {tabs.map((tab, index) => (
          <Button
            key={tab}
            ref={(el) => { tabsRef.current[index] = el; }}
            variant="text"
            onClick={() => setActiveTab(index)}
            className={`!rounded-none !h-12 !px-6 !text-base ${activeTab === index ? 'text-primary' : 'text-on-surface-variant'}`}
          >
            {tab}
          </Button>
        ))}
      </div>
      <div
        className="absolute bottom-0 h-1 bg-primary rounded-t-full transition-all duration-300 ease-out"
        style={indicatorStyle}
      />
    </div>
  );
};

export default Tabs;