import React, { useState, useEffect, useRef } from 'react';

interface StatCounterProps {
  endValue: number;
}

const StatCounter: React.FC<StatCounterProps> = ({ endValue }) => {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const animationFrameId = useRef<number | null>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          const duration = 1500; // Animation duration in ms
          const startTimestamp = performance.now();
          
          const step = (timestamp: number) => {
            const progress = timestamp - startTimestamp;
            const currentProgress = Math.min(progress / duration, 1);
            const currentCount = Math.floor(currentProgress * endValue);
            
            setCount(currentCount);

            if (currentProgress < 1) {
              animationFrameId.current = requestAnimationFrame(step);
            } else {
              setCount(endValue); // Ensure it ends on the exact value
            }
          };
          
          animationFrameId.current = requestAnimationFrame(step);
          observer.disconnect();
        }
      },
      { threshold: 0.5 }
    );

    const currentRef = ref.current;
    if (currentRef) {
      observer.observe(currentRef);
    }
    
    return () => {
        if (currentRef) {
            observer.unobserve(currentRef);
        }
        if (animationFrameId.current) {
            cancelAnimationFrame(animationFrameId.current);
        }
    }
  }, [endValue]);

  return <span ref={ref}>{count.toLocaleString()}</span>;
};

export default StatCounter;