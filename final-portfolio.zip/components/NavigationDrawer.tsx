import React from 'react';
import { SECTIONS, PERSONAL_INFO } from '../constants';
import { LightbulbIcon, XIcon } from './icons/Icons';
import Button from './Button';

type SectionType = typeof SECTIONS[number];

interface NavigationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activeSection: SectionType;
  setActiveSection: (section: SectionType) => void;
}

const NavigationDrawer: React.FC<NavigationDrawerProps> = ({ isOpen, onClose, activeSection, setActiveSection }) => {

  const handleSelectSection = (section: SectionType) => {
    setActiveSection(section);
    onClose();
  };

  return (
    <div
      className={`fixed inset-0 z-50 transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
      aria-hidden={!isOpen}
    >
      {/* Scrim */}
      <div className="absolute inset-0 bg-scrim/30" onClick={onClose} />

      {/* Drawer */}
      <div
        className={`absolute top-0 left-0 bottom-0 w-80 max-w-[calc(100vw-3.5rem)] bg-surface-container-low shadow-xl transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-center justify-between p-4 border-b border-outline-variant">
           <div className="flex items-center space-x-2">
            <div className="w-8 h-8 flex items-center justify-center bg-primary-container rounded-full">
              <LightbulbIcon className="h-5 w-5 text-on-primary-container" />
            </div>
            <span className="font-display text-lg font-bold text-on-surface tracking-tight">{PERSONAL_INFO.name}</span>
          </div>
          <Button variant="text" onClick={onClose} className="!w-10 !h-10 !p-0 !rounded-full">
            <XIcon className="w-6 h-6" />
          </Button>
        </div>
        <nav className="p-4">
          <ul>
            {SECTIONS.map((section) => (
              <li key={section}>
                <button
                  onClick={() => handleSelectSection(section)}
                  className={`w-full text-left h-14 px-4 flex items-center rounded-full font-medium text-base transition-colors ${
                    activeSection === section
                      ? 'bg-secondary-container text-on-secondary-container'
                      : 'text-on-surface-variant hover:bg-on-surface/5'
                  }`}
                >
                  {section}
                </button>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </div>
  );
};

export default NavigationDrawer;