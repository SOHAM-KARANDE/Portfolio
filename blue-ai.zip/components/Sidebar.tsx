import React from 'react';

const MessageSquareIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
);
const SettingsIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 0 2l-.15.08a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.38a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1 0-2l.15-.08a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>
);
const HelpCircleIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/></svg>
);

interface SidebarProps {
  onSettingsClick: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ onSettingsClick }) => {
  return (
    <div className="flex-shrink-0 flex flex-col w-60 bg-mac-sidebar-light dark:bg-mac-sidebar-dark backdrop-blur-xl border-r border-black/5 dark:border-white/5 p-3 space-y-2">
      <div className="flex items-center space-x-2 p-2 h-8">
        <div className="w-3 h-3 rounded-full bg-mac-red"></div>
        <div className="w-3 h-3 rounded-full bg-mac-yellow"></div>
        <div className="w-3 h-3 rounded-full bg-mac-green"></div>
      </div>
      <div className="flex-grow pt-4">
        <button className="w-full flex items-center space-x-3 px-3 py-2 rounded-lg bg-mac-blue text-white font-semibold">
          <MessageSquareIcon className="w-5 h-5" />
          <span>New Chat</span>
        </button>
      </div>
      <div className="space-y-1">
         <button 
          onClick={onSettingsClick}
          className="w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-mac-text-primary-light dark:text-mac-text-primary-dark hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
          <SettingsIcon className="w-5 h-5" />
          <span>Settings</span>
        </button>
        <button onClick={onSettingsClick} className="w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-mac-text-primary-light dark:text-mac-text-primary-dark hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
          <HelpCircleIcon className="w-5 h-5" />
          <span>Help & About</span>
        </button>
      </div>
    </div>
  );
};
