import React, { useEffect, useRef } from 'react';
import { Message } from './Message';
import { MessageType } from '../types';

interface ChatViewProps {
  messages: MessageType[];
  isLoading: boolean;
  onUpdateMessage: (id: string, newContent: string) => void;
  onRegenerateImage: (id:string, newPrompt: string) => void;
}

export const ChatView: React.FC<ChatViewProps> = ({ messages, isLoading, onUpdateMessage, onRegenerateImage }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  return (
    <div ref={scrollRef} className="flex-1 overflow-y-auto p-6">
      <div className="max-w-4xl mx-auto">
        {messages.map((msg) => (
          <Message key={msg.id} message={msg} onUpdateMessage={onUpdateMessage} onRegenerateImage={onRegenerateImage} />
        ))}
        {isLoading && (
          <div className="flex items-start space-x-4 my-6">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-mac-component-bg-light dark:bg-mac-component-bg-dark flex items-center justify-center shadow-sm">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5 text-mac-blue"><path d="M12 8V4H8"/><rect width="16" height="12" x="4" y="8" rx="2"/><path d="M2 14h2"/><path d="M20 14h2"/><path d="M15 13v2"/><path d="M9 13v2"/></svg>
            </div>
            <div className="max-w-xl">
              <div className="bg-mac-component-bg-light dark:bg-mac-component-bg-dark rounded-xl p-4 shadow-sm">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-mac-text-secondary-light dark:bg-mac-text-secondary-dark rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                  <div className="w-2 h-2 bg-mac-text-secondary-light dark:bg-mac-text-secondary-dark rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                  <div className="w-2 h-2 bg-mac-text-secondary-light dark:bg-mac-text-secondary-dark rounded-full animate-bounce"></div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
