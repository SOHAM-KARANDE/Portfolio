import React from 'react';
import type { Theme } from '../hooks/useTheme';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  theme: Theme;
  setTheme: (theme: Theme) => void;
}

const SunIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/></svg>
);
const MoonIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></svg>
);
const LaptopIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 16V7a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v9m16 0H4m16 0 1.28 2.55A1 1 0 0 1 20.28 20H3.72a1 1 0 0 1-.9-1.45L4 16"/></svg>
);

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, theme, setTheme }) => {
  if (!isOpen) return null;

  const ThemeButton = ({ value, icon, label }: { value: Theme, icon: React.ReactNode, label: string }) => (
    <button
      onClick={() => setTheme(value)}
      className={`flex-1 flex flex-col items-center justify-center p-3 rounded-lg border-2 transition-colors ${
        theme === value ? 'border-mac-blue bg-mac-blue/10' : 'border-transparent hover:bg-black/5 dark:hover:bg-white/5'
      }`}
    >
      {icon}
      <span className="text-xs mt-1 font-medium">{label}</span>
    </button>
  );

  return (
    <div className="fixed inset-0 bg-black/30 backdrop-blur-sm flex items-center justify-center z-50" onClick={onClose}>
      <div
        className="bg-mac-component-bg-light/95 dark:bg-mac-component-bg-dark/95 backdrop-blur-lg text-mac-text-primary-light dark:text-mac-text-primary-dark rounded-xl shadow-2xl w-full max-w-md p-6 border border-black/10 dark:border-white/10"
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="text-xl font-semibold mb-6">Settings</h2>
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium text-mac-text-secondary-light dark:text-mac-text-secondary-dark mb-2 block">Appearance</label>
            <div className="flex space-x-2 bg-black/5 dark:bg-white/5 p-1 rounded-xl">
              <ThemeButton value="light" icon={<SunIcon className="w-6 h-6" />} label="Light" />
              <ThemeButton value="dark" icon={<MoonIcon className="w-6 h-6" />} label="Dark" />
              <ThemeButton value="system" icon={<LaptopIcon className="w-6 h-6" />} label="System" />
            </div>
          </div>
          <div>
            <h3 className="text-lg font-semibold mt-8 mb-4">About BLUE AI</h3>
            <p className="text-sm text-mac-text-secondary-light dark:text-mac-text-secondary-dark">
              A sophisticated, multimodal AI conversational agent designed to provide intelligent and context-aware responses in various formats.
            </p>
          </div>
        </div>
        <div className="mt-8 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-mac-blue text-white rounded-lg font-semibold text-sm hover:opacity-90 transition-opacity"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
