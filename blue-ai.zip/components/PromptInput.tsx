import React from 'react';
import { OutputFormat } from '../types';

interface PromptInputProps {
  prompt: string;
  setPrompt: (prompt: string) => void;
  outputFormat: OutputFormat;
  setOutputFormat: (format: OutputFormat) => void;
  onSubmit: () => void;
  isLoading: boolean;
}

const ImageIcon = (props: React.SVGProps<SVGSVGElement>) => ( <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg> );
const FileTextIcon = (props: React.SVGProps<SVGSVGElement>) => ( <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M16 13H8"/><path d="M16 17H8"/><path d="M10 9H8"/></svg> );
const SendIcon = (props: React.SVGProps<SVGSVGElement>) => ( <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg> );

export const PromptInput: React.FC<PromptInputProps> = ({ prompt, setPrompt, outputFormat, setOutputFormat, onSubmit, isLoading }) => {
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (!isLoading) {
        onSubmit();
      }
    }
  };

  const FormatButton = ({ value, icon, label }: { value: OutputFormat, icon: React.ReactNode, label: string }) => (
    <button
      onClick={() => setOutputFormat(value)}
      className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
        outputFormat === value ? 'bg-mac-blue text-white' : 'bg-black/5 dark:bg-white/5 text-mac-text-secondary-light dark:text-mac-text-secondary-dark hover:bg-black/10 dark:hover:bg-white/10'
      }`}
    >
      {icon}
      <span>{label}</span>
    </button>
  );

  return (
    <div className="p-4 border-t border-black/5 dark:border-white/5">
      <div className="bg-mac-component-bg-light dark:bg-mac-component-bg-dark rounded-xl p-2 border border-black/10 dark:border-white/10 focus-within:ring-2 focus-within:ring-mac-blue transition-all">
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Ask BLUE AI anything..."
          className="w-full bg-transparent text-mac-text-primary-light dark:text-mac-text-primary-dark placeholder:text-mac-text-secondary-light dark:placeholder:text-mac-text-secondary-dark focus:outline-none resize-none p-2 text-base"
          rows={1}
          disabled={isLoading}
        />
        <div className="flex justify-between items-center mt-2 px-2 pb-1">
          <div className="flex items-center space-x-2">
            <FormatButton value={OutputFormat.TEXT} icon={<FileTextIcon className="w-4 h-4" />} label="Text" />
            <FormatButton value={OutputFormat.IMAGE} icon={<ImageIcon className="w-4 h-4" />} label="Image" />
          </div>
          <button 
            onClick={onSubmit} 
            disabled={isLoading || !prompt.trim()}
            className="w-8 h-8 flex items-center justify-center rounded-full bg-mac-blue text-white disabled:opacity-50 disabled:cursor-not-allowed hover:opacity-90 transition-opacity flex-shrink-0"
          >
            {isLoading ? (
                <div className="w-4 h-4 border-2 border-white/50 border-t-white rounded-full animate-spin"></div>
            ) : (
                <SendIcon className="w-4 h-4" />
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
