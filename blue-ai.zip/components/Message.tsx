import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { MessageType, Role } from '../types';

interface MessageProps {
  message: MessageType;
  onUpdateMessage: (id: string, newContent: string) => void;
  onRegenerateImage: (id: string, newPrompt: string) => void;
}

const UserIcon = (props: React.SVGProps<SVGSVGElement>) => ( <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg> );
const BotIcon = (props: React.SVGProps<SVGSVGElement>) => ( <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 8V4H8"/><rect width="16" height="12" x="4" y="8" rx="2"/><path d="M2 14h2"/><path d="M20 14h2"/><path d="M15 13v2"/><path d="M9 13v2"/></svg> );
const EditIcon = (props: React.SVGProps<SVGSVGElement>) => ( <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg> );
const SaveIcon = (props: React.SVGProps<SVGSVGElement>) => ( <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg> );
const CancelIcon = (props: React.SVGProps<SVGSVGElement>) => ( <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></svg> );
const RegenerateIcon = (props: React.SVGProps<SVGSVGElement>) => ( <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M3 21a9 9 0 0 1 .46-3.26"/></svg> );

export const Message: React.FC<MessageProps> = ({ message, onUpdateMessage, onRegenerateImage }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedContent, setEditedContent] = useState(message.content);
  const [editedPrompt, setEditedPrompt] = useState(message.prompt || '');
  const isUser = message.role === Role.USER;

  const handleEdit = () => setIsEditing(true);
  const handleCancel = () => setIsEditing(false);

  const handleSave = () => {
    onUpdateMessage(message.id, editedContent);
    setIsEditing(false);
  };

  const handleRegenerate = () => {
    onRegenerateImage(message.id, editedPrompt);
    setIsEditing(false);
  };

  const bubbleClasses = isUser
    ? 'bg-mac-blue text-white'
    : 'bg-mac-component-bg-light dark:bg-mac-component-bg-dark text-mac-text-primary-light dark:text-mac-text-primary-dark';

  const renderContent = () => {
    if (isEditing) {
      if (message.format === 'text') {
        return (
          <textarea
            value={editedContent}
            onChange={(e) => setEditedContent(e.target.value)}
            className="w-full h-40 p-2 bg-white dark:bg-black/50 border border-mac-blue rounded-md focus:outline-none focus:ring-2 focus:ring-mac-blue text-black dark:text-white"
          />
        );
      } else { // image
        return (
          <div className="space-y-2">
            <img src={message.content} alt={message.prompt} className="rounded-lg max-w-sm" />
            <input
              type="text"
              value={editedPrompt}
              onChange={(e) => setEditedPrompt(e.target.value)}
              className="w-full p-2 bg-white dark:bg-black/50 border border-mac-blue rounded-md focus:outline-none focus:ring-2 focus:ring-mac-blue text-black dark:text-white"
            />
          </div>
        );
      }
    }

    if (message.format === 'text') {
      return <ReactMarkdown className="prose prose-sm dark:prose-invert max-w-none prose-p:text-inherit prose-headings:text-inherit prose-strong:text-inherit">{message.content}</ReactMarkdown>;
    } else { // image
      return <img src={message.content} alt={message.prompt} className="rounded-lg max-w-sm" />;
    }
  };

  return (
    <div className={`flex items-start space-x-4 my-6 ${isUser ? 'justify-end' : ''}`}>
      {!isUser && <div className="flex-shrink-0 w-8 h-8 rounded-full bg-mac-component-bg-light dark:bg-mac-component-bg-dark flex items-center justify-center shadow-sm">{<BotIcon className="w-5 h-5 text-mac-blue" />}</div>}
      
      <div className={`relative group max-w-2xl ${isUser ? 'order-1' : 'order-2'}`}>
        <div className={`${bubbleClasses} rounded-xl p-4 shadow-sm`}>
          {renderContent()}
        </div>
        {!isUser && !isEditing && (
          <button onClick={handleEdit} className="absolute -top-2 -right-2 p-1 rounded-full bg-white dark:bg-gray-600 text-mac-text-secondary-light dark:text-mac-text-secondary-dark opacity-0 group-hover:opacity-100 transition-opacity shadow-md">
            <EditIcon className="w-4 h-4" />
          </button>
        )}
        {isEditing && (
          <div className="mt-2 flex space-x-2">
            <button onClick={message.format === 'text' ? handleSave : handleRegenerate} className="flex items-center space-x-1 px-3 py-1 bg-mac-blue text-white text-xs font-semibold rounded-md hover:opacity-90">
              {message.format === 'text' ? <SaveIcon className="w-3 h-3"/> : <RegenerateIcon className="w-3 h-3"/>}
              <span>{message.format === 'text' ? 'Save' : 'Regenerate'}</span>
            </button>
            <button onClick={handleCancel} className="flex items-center space-x-1 px-3 py-1 bg-gray-200 dark:bg-gray-700 text-xs font-semibold rounded-md hover:bg-opacity-80">
              <CancelIcon className="w-3 h-3"/>
              <span>Cancel</span>
            </button>
          </div>
        )}
      </div>

      {isUser && <div className="flex-shrink-0 w-8 h-8 rounded-full bg-mac-component-bg-light dark:bg-mac-component-bg-dark flex items-center justify-center shadow-sm order-2">{<UserIcon className="w-5 h-5 text-mac-text-secondary-light dark:text-mac-text-secondary-dark" />}</div>}
    </div>
  );
};
